function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}function setup() {
  createCanvas(800, 600);
  background(0);
}

function draw() {
  if (mouseIsPressed) {
    stroke(255);
    strokeWeight(4);
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}